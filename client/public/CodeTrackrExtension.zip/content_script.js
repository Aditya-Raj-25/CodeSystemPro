// Example Logic: Detect LeetCode submission success
const detectLeetCodeSuccess = () => {
    const successNode = document.querySelector('[data-e2e-locator="submission-result"]');
    if (successNode && successNode.innerText.includes('Accepted')) {
        const url = window.location.href;
        const problemSlug = url.match(/problems\\/([^ /]+)/)[1];

        // In actual implementation we'd need to fetch the language block from DOM or intercept network
        const data = {
            platform: 'LeetCode',
            problemName: problemSlug,
            problemURL: `https://leetcode.com/problems/${problemSlug}`,
            submissionId: url.match(/submissions\\/([^ /]+)/)[1] || 'unknown',
      // Code extraction is tricky here without DOM traversal.
    };

        chrome.runtime.sendMessage({
            action: 'SYNC_SUBMISSION',
            data
        });
    }
};

// Check for successful UI after brief delay to allow React rendering
setTimeout(() => {
    if (window.location.hostname === 'leetcode.com') {
        detectLeetCodeSuccess();
    }
}, 3000);
