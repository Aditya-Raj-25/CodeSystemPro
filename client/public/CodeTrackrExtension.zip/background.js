// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'SYNC_SUBMISSION') {
        chrome.storage.local.get(['token'], (result) => {
            const token = result.token;
            if (!token) {
                console.warn('No authentication token found. Cannot sync submission.');
                sendResponse({ success: false, error: 'Not authenticated' });
                return;
            }

            console.log('Intercepted successful submission:', request.data);

            fetch('http://localhost:5000/api/sync/manual', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(request.data)
            })
                .then(response => response.json())
                .then(data => {
                    console.log('Submission synced successfully', data);
                    sendResponse({ success: true, data });
                })
                .catch(error => {
                    console.error('Error syncing submission:', error);
                    sendResponse({ success: false, error: error.message });
                });
        });

        return true; // Keep the message channel open for async response
    }
});
